from django.contrib import admin
from .models import Paciente, Categoria, Estudio, MedicoSolicitante, Pedido, Radiologo, Subcategoria


admin.site.register(Paciente)