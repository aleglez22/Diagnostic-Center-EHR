from django.apps import AppConfig


class HcappConfig(AppConfig):
    name = 'hcapp'
